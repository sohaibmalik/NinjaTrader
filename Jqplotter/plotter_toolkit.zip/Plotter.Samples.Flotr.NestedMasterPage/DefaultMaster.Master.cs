﻿#region

using System;
using System.Web.UI;

#endregion

namespace Plotter.Samples.Flotr.NestedMasterPage
{
    public partial class DefaultMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}