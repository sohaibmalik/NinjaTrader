﻿#region

using System;
using System.Web.UI;

#endregion

namespace Plotter.Samples.Flot.NestedMasterPage
{
    public partial class NestedMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}