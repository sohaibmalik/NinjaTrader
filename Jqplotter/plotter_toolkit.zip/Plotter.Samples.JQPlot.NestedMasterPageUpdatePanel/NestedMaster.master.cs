﻿#region

using System;
using System.Web.UI;

#endregion

namespace Plotter.Samples.JQPlot.NestedMasterPageUpdatePanel
{
    public partial class NestedMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}