﻿#region

using System;

#endregion

namespace Plotter.Samples.Flotr2.MasterPage
{
    public partial class DefaultMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}